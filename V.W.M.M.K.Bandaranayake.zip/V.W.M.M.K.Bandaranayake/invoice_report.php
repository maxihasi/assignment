<?php
session_start();

$now = date_create()->format('Y-m-d');
            include 'dbconnection.php';


?>

<html>
<head>
    <style>
        h3{color:deepskyblue;font-size:50px;}
        h4{font-size:200px;color: aliceblue;}
        .ret{border:2px black solid;background-color: darksalmon;}
        .divl{margin:auto;width:400px;height:auto;padding-top:20px;background-color:aliceblue;margin-top:50px;border:2px solid blue; border-radius:20px;} 
        h5{color: aliceblue;}
        .a1{text-decoration:none;color:aliceblue;}
        .ap{position:absolute; right:0px;}
        .ad{position:absolute; right:90px;}
        h6{font-weight:300px;color: aliceblue;}
        p{font-size:20px;}
         button{color:black;background-color: deepskyblue;}
        div{font-size:12px;}
        
    </style>
    <link rel="stylesheet" href="css/bootstrap.css" type="text/css">
</head>
 <body background="44.jpg">
        
      <div class="container divl" >
        <div class="row">
        <div class="col-4"></div>
        <div class="col-6"></div>
        <div class="col-2"><a href="interface.php"><button>Previous</button></a></div>
        </div>
    
        <center><h3>Invoice Report</h3></center><br><br>
     <form method="post" action=""><center>
  Enter Date:<input type="text" name="date" required/>
  <input type="submit" value="Search"/>
         </center>
</form>
        
    <!-- display details-->
    <div class="">
    <?php
        $date=$_POST['date'];
        $search=$_POST['search'];
        
        $sql1="select i.invoice_no,i.date,i.customer,c.district,i.item_count,i.amount from invoice i,customer c where i.id=c.id and i.date='$date'";
        //$sql1->execute(["%".$_POST["date"]."%", "%".$_POST["search"]."%"]);
        $result=mysqli_query($conn,$sql1)or die(mysqli_error($conn));

    if(!$result){
        die("could not connect".mysqli_error());
    }
    ?>
        <div class="row border bg-dark">
                 <div class="col-1"></div>
                 <div class="col-1"><h6>invoice_no</h6></div>
                 <div class="col-2"><h6>date</h6></div>
                 <div class="col-2"><h6>customer</h6></div>
                 <div class="col-2"><h6>district</h6></div>
                 <div class="col-2"><h6>item_count</h6></div>
                 <div class="col-2"><h6>amount</h6></div>   
        </div>
        
        <?php
        $retDir = " ";
         while ($row=mysqli_fetch_array($result)){ 
             
        ?>
        <div class="row border bg-info text-white">
              <div class="col-1"></div>
            <div class="col-1"><?php echo"{$row['invoice_no']}"; ?></div>
            <div class="col-2"><?php echo"{$row['date']}"; ?></div>
            <div class="col-2"><?php echo" {$row['customer']}"; ?></div>
             <div class="col-2"><?php echo" {$row['district']}"; ?></div>
            <div class="col-2"><?php echo" {$row['item_count']}"; ?></div>
            <div class="col-2"><?php echo"{$row['amount']}"; ?></div>
            
             
        </div>
        <?php }//} ?><br>
        
       </div> <br><br>
         
       
        
       
    
</body>
</html>