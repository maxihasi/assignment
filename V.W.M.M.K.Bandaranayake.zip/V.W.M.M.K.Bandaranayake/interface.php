<?php
     session_start();
     
    include 'dbconnection.php';
 
?>
<html>
    <head>
        
         <link rel="stylesheet" href="css/bootstrap.css" type="text/css">
   
        <style>
            h4{color:cornflowerblue;font-size:40px; }
          .divl{width:500px;height:500px; background-color:azure; border:2px solid blue; border-radius:20px;margin: 100px auto;} 
            .am{position:absolute; left:5px; right:50px;}
            .ap{position:absolute; right:0px;}
            .ad{position:absolute; right:90px;}
            .button{width:250px;}
            .divh{height:60px;}
        </style>
       
    </head>
         <body background="44.jpg">
          <div class="divl"><br><br>
           
            <div class="row">
                <div class="col-3"></div>
                <div class="col-8">
                <a href="customer.php" class="btn btn-info button">Add Customer</a>
                </div>
               
            </div><br><br>
            <div class="row">
                <div class="col-3"></div>
                <div class="col-8">
                <a href="item.php" class="btn btn-info button">Add item</a>
                </div>
                
            </div><br><br>
            
            <div class="row">
                <div class="col-3"></div>
                <div class="col-8">
                <a href="invoice_report.php" class="btn btn-info button">Invoice Report</a>
                </div>
                
            </div><br><br>
             
             <div class="row">
                <div class="col-3"></div>
                <div class="col-8">
                <a href="invoice_item_report.php" class="btn btn-info button">Invoice Item Report</a>
                </div>
                
            </div><br><br>
             
             <div class="row">
                <div class="col-3"></div>
                <div class="col-8">
                <a href="item_report.php" class="btn btn-info button">Item Report</a>
                </div>
                
            </div><br><br>
            
             </div>
      
    </body>
</html>