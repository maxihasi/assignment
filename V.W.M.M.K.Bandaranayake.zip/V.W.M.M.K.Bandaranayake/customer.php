<?php
session_start();
include 'dbconnection.php';
$statusMsg = '';

$now = date_create()->format('Y-m-d');

if(isset($_POST["let_add"]) ){
  
     $title=$_POST['title'];
    $first_name=$_POST['first_name'];
    $middle_name=$_POST['middle_name'];
    $last_name=$_POST['last_name'];
     $contact_no=$_POST['contact_no'];
    $district=$_POST['district'];
   
    $sql = "insert into customer (`title`, `first_name`, `middle_name`, `last_name`, `contact_no`, `district`) VALUES
('".$title."','".$first_name."','".$middle_name."','".$last_name."','".$contact_no."','".$district."')";
            
            $insert=mysqli_query($conn,$sql) or die(mysqli_error($conn));
            
}?>

<html>
<head>
    <style>
        .ret{border:2px black solid;background-color: darksalmon;}
        .divl{margin:auto; width:400px;height:auto;padding-top:40px;background-color:aliceblue;margin-top:100px;border:2px solid blue; border-radius:20px;} 
        h6{color: aliceblue;}
        .a1{text-decoration:none;color:aliceblue;}
        .ap{position:absolute; right:0px;}
        .ad{position:absolute; right:90px;}
        h2{font-weight:200px; color:black;}
        button{color:black;background-color: deepskyblue;}
        div{font-size:12px;}
    </style>
    <link rel="stylesheet" href="css/bootstrap.css" type="text/css">
</head>

<body>
     <div class="container divl" >
         <div class="row">
                <div class="col-4"></div>
                <div class="col-6"></div>
                <div class="col-2"><a href="interface.php"><button>Previous</button></a></div>
              </div>
        
     <center><h2>Add Employee</h2></center>
        
        
       
         <form action="" method="post" enctype="multipart/form-data">
            
             <div class="row">
                 <div class="col-2"></div>
                <div class="col-8">
                    Date:<?php echo date("m/d/Y"); ?>
                </div>
               <div class="col-2"></div>
            
             </div>
             
             
            <div class="row">
                <div class="col-2"></div>
                <div class="col-8">
               
                    title:<select class="custom-select,se form-control " size="1" name="title">
                              <option selected>Select title</option>
                              <option>MR</option>
                              <option>MRS</option>
                              <option>DR</option>
                              <option>Miss</option> 
                              </select>
                </div>
                  <div class="col-2"></div>
                 
             </div>
              <div class="row">
                <div class="col-2"></div>
                <div class="col-8">
                    first_name:<input type="text" class="form-control" name="first_name" placeholder="Enter first_name">
                </div>
              <div class="col-2"></div>
            
             </div>
         <div class="row">
                <div class="col-2"></div>
                <div class="col-8">
                    middle_name:<input type="text" class="form-control" name="middle_name" placeholder="Enter middle_name">
                </div>
              <div class="col-2"></div>
            </div>  
              <div class="row">
                <div class="col-2"></div>
                <div class="col-8">
                    last_name:<input type="text" class="form-control" name="last_name" placeholder="Enter last_name">
                </div>
              <div class="col-2"></div>
            </div>             
             <div class="row">
                <div class="col-2"></div>
                <div class="col-8">
                   contact_no:<input type="text" class="form-control" name="contact_no" placeholder="Enter contact_no">
                </div>
              <div class="col-2"></div>
             </div>
              <div class="row">
                <div class="col-2"></div>
                <div class="col-8">
                    district:<input type="text" class="form-control" name="district" placeholder="Enter district">
                </div>
              <div class="col-2"></div>
            
             </div>
            <br>
             
        
              <div class="row">
                <div class="col-2"></div>
                <div class="col-8"><input type="submit" name ="let_add"   value="Save customer"  class="btn btn-info"></div>
                <div class="col-2"></div>
              </div>
              
        </form>
         
       
        
       
    
</body>
</html>