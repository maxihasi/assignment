<?php
$dbhost="localhost";
$dbuser="root";
$pw="";
$db="assignment1";

$conn=mysqli_connect($dbhost,$dbuser,$pw);

if(!$conn){
    die("could not connect".mysqli_error());
}

mysqli_select_db($conn,$db);

?>


