<?php
session_start();
include 'dbconnection.php';
$statusMsg = '';

$now = date_create()->format('Y-m-d');

if(isset($_POST["let_add"]) ){
  
     $item_code=$_POST['item_code'];
     $item_name=$_POST['item_name'];
    $item_category=$_POST['item_category'];
    $item_subcategory=$_POST['item_subcategory'];
     $quantity=$_POST['quantity'];
    $unit_price=$_POST['unit_price'];
   
    $sql = "insert into item (`item_code`, `item_name`,  `item_category`, `item_subcategory`,`quantity`, `unit_price`) VALUES
('".$item_code."','".$item_name."','".$item_category."','".$item_subcategory."','".$quantity."','".$unit_price."')";
            
            $insert=mysqli_query($conn,$sql) or die(mysqli_error($conn));
            
}?>

<html>
<head>
    <style>
        .ret{border:2px black solid;background-color: darksalmon;}
        .divl{margin:auto; width:400px;height:auto;padding-top:40px;background-color:aliceblue;margin-top:100px;border:2px solid blue; border-radius:20px;} 
        h6{color: aliceblue;}
        .a1{text-decoration:none;color:aliceblue;}
        .ap{position:absolute; right:0px;}
        .ad{position:absolute; right:90px;}
        h2{font-weight:200px; color:black;}
        button{color:black;background-color: deepskyblue;}
        div{font-size:12px;}
    </style>
    <link rel="stylesheet" href="css/bootstrap.css" type="text/css">
</head>

<body>
     <div class="container divl" >
         <div class="row">
                <div class="col-4"></div>
                <div class="col-6"></div>
                <div class="col-2"><a href="interface.php"><button>Previous</button></a></div>
              </div>
        
     <center><h2>Add Item</h2></center>
        
        
       
         <form action="" method="post" enctype="multipart/form-data">
            
             <div class="row">
                 <div class="col-2"></div>
                <div class="col-8">
                    Date:<?php echo date("m/d/Y"); ?>
                </div>
               <div class="col-2"></div>
            
             </div>
             
             
            
              <div class="row">
                <div class="col-2"></div>
                <div class="col-8">
                    item_code:<input type="text" class="form-control" name="item_code" placeholder="Enter item_code">
                </div>
              <div class="col-2"></div>
            
             </div>
         <div class="row">
                <div class="col-2"></div>
                <div class="col-8">
                    item_name:<input type="text" class="form-control" name="item_name" placeholder="Enter item_name">
                </div>
              <div class="col-2"></div>
            </div>  
              <div class="row">
                <div class="col-2"></div>
                <div class="col-8">
               
                    item_category:<select class="custom-select,se form-control " size="1" name="item_category">
                              <option selected>Select item</option>
                              <option>Printers</option>
                              <option>Laptops</option>
                              <option>Gadgets</option>
                              <option>Ink bottels</option> 
                              <option>Cartridges</option> 
                              </select>
                   
                </div>
                  <div class="col-2"></div>
                 
             </div>  
             <div class="row">
                <div class="col-2"></div>
                <div class="col-8">
               
                    item_subcategory:<select class="custom-select,se form-control " size="1" name="item_subcategory">
                              <option selected>Select item_subcatogery</option>
                              <option>HP</option>
                              <option>Dell</option>
                              <option>Lenovo</option>
                              <option>Acer</option> 
                              <option>Samsung</option> 
                              </select>
               
                </div>
                  <div class="col-2"></div>
                 
             </div>       
             <div class="row">
                <div class="col-2"></div>
                <div class="col-8">
                   quantity:<input type="text" class="form-control" name="quantity" placeholder="Enter quantity">
                </div>
              <div class="col-2"></div>
             </div>
              <div class="row">
                <div class="col-2"></div>
                <div class="col-8">
                   unit_price:<input type="text" class="form-control" name="unit_price" placeholder="Enter unit_price">
                </div>
              <div class="col-2"></div>
            
             </div>
            <br>
             
        
              <div class="row">
                <div class="col-2"></div>
                <div class="col-8"><input type="submit" name ="let_add"   value="Save item"  class="btn btn-info"></div>
                <div class="col-2"></div>
              </div>
              
        </form>
         
       
        
       
    
</body>
</html>